﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CodeComb.TestFixture.Host;
using HelloWorld;
using Xunit;

namespace HelloWorld.Tests
{
    public class OutputTests : HostTestFixture<Startup>
    {
        [Fact(DisplayName = "访问首页检查是否返回Hello World!")]
        public async Task home_test()
        {
            var res = await client.GetAsync("/");
            var result = await res.Content.ReadAsStringAsync();
            Assert.Equal("Hello World!", result);
        }

        [Fact(DisplayName = "随机访问页面检查是否返回Hello World!")]
        public async Task random_routing_test()
        {
            var res = await client.GetAsync("/blablabla");
            var result = await res.Content.ReadAsStringAsync();
            Assert.Equal("Hello World!", result);
        }
    }
}
